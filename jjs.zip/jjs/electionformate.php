<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<? include_once("includes/pagesource.php"); ?>
</head>

<body class="inner-header">
    <? include_once("includes/header.php"); ?>
    <div class="container-fluid py-3 light-bk">
        <div class="container">
            <div class="row">
                <div class="col-12 breadcrumb">
                    <ol>
                        <li>
                            <a href="index.php">Home</a>
                        </li>
                        <li>
                            Election Formate
                        </li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid py-3 py-md-5">
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-9">
                    <h3 class="inner-heading">Election Formate</h3>
                    <div class="resolution-content">
                        <div>
                            <h3 class="mb-3">2022</h3>
                            <table class="table mb-0 views-view-table">
                                <thead>
                                    <th>Format</th>
                                    <th>District</th>
                                    <th>Document</th>
                                </thead>
                                <tbody>
                                    <td>Format C-7</td>
                                    <td>North 24 Parganas</td>
                                    <td><a style="color:#0d6efd;">Clck to download</a></td>
                                </tbody>
                            </table>
                        </div>
                        <div>
                            <h3 class="mb-3">2021</h3>
                            <table class="table mb-0 views-view-table">
                                <thead>
                                    <th>Format</th>
                                    <th>District</th>
                                    <th>Document</th>
                                </thead>
                                <tbody>
                                    <td>Format C-7</td>
                                    <td>North 24 Parganas</td>
                                    <td><a style="color:#0d6efd;">Clck to download</a></td>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <? include_once("includes/inner-right.php"); ?>
            </div>
        </div>
    </div>
    <? include_once("includes/footer.php"); ?>
</body>

</html>