<!DOCTYPE html>
<html lang="en">
<? include_once("includes/pagesource.php"); ?>

<body>
    <? include_once("includes/header.php"); ?>
    <div class="container-fluid py-3 light-bk">
        <div class="container">
            <div class="row">
                <div class="col-12 breadcrumb">
                    <ol>
                        <li>
                            <a href="index.php">Home</a>
                        </li>
                        <li>
                            Conatct Us
                        </li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <style>
        .reachus-box .input-from-group {
  display: flex;
  align-items: center;
  padding: 0;
  margin-bottom: 15px;
}

.reachus-box .form-group input {
  height: 55px;
  border-bottom: 2px solid #000;
  width: 100%;
  padding: 22px;
  border: none;
  border-bottom: 0;
  border-radius: 0.25rem;
    border: 2px solid;
}

.reachus-box .form-group textarea {
  height: 55px;
  border-bottom: 2px solid #000;
  width: 100%;
  padding: 22px;
  border: none;
  border-bottom: 0;
  height: 150px;
  border-radius: 0.25rem;
    border: 2px solid;
}

.reachus-box .form-group .input-label {
  margin: 0;
  width: 12%;
  border-right: 2px solid #123a68;
  color: #123a68;
}

.reach-us {
  background: white;
  padding: 50px 0;
}

.reach-us-box {
  padding: 0;
}
.addbox ul{
    margin-bottom: 0;
    margin-left: 0;
    padding: 0;
}
.addbox li{
    list-style: none;
    font-size: 16px;
    display: flex;
    margin-bottom: 15px;
}
.addbox li:last-child{
    margin-bottom: 0px;
}
.reachus-box button
{
    display: inline-block;
    /* color: #fff !important; */
    font-size: 18px;
    transition: .5s;
    border: 0;
       padding: 15px 50px;
    background: black;
    color: white;
  
}
    </style>
    <div class="container-fluid py-3">
        <div class="container">
            <div class="row">
            <div class="col-12 col-md-6">
                    <h3 class="inner-heading">Contact Info</h3>
                    <div class="addbox" style="
    background: #ffefbf;
    padding: 25px;
    border-radius: 0.25rem;
">
                        <h3 style="
    font-size: 20px;
    font-weight: bold;
">Address</h3>
                        <ul>
                            <li><i class="fas fa-map-marker" style="margin-top: 4px;margin-right: 11px;"></i> House Number 4 , Shanti Vidya Nagri , Mira Road East , Thane , Maharashtra , Pin - 401107 , India</li>
                            <li><i class="fas fa-map-marker" style="margin-top: 4px;margin-right: 11px;"></i> House Number 101 , Sai Dham , Chattarpur Enclave , South Delhi , India</li>
                            <li><i class="fas fa-map-marker" style="margin-top: 4px;margin-right: 11px;"></i> House number 1 / 2528 , Sai Dham , Kalyani , West Bengal , India</li>
                        </ul>
                    </div>
                    <div class="addbox" style="
    background: #ffc6c6;
    padding: 25px;
    border-radius: .25rem;
    margin-top: 1rem;
">
                        <h3 style="
    font-size: 20px;
    font-weight: bold;
">Help Line Number / Public Relation Officer</h3>
                        <ul>
                            <li><i class="fas fa-mobile" style="margin-top: 4px;margin-right: 11px;"></i> + 91 76662 77459</li>
                        </ul>
                    </div>
                    <div class="addbox" style="
    background: #c6f9ff;
    padding: 25px;
    border-radius: 0.25rem;
    margin-top: 1rem;
">
                        <h3 style="
    font-size: 20px;
    font-weight: bold;
">E-mail</h3>
                        <ul>
                            <li><i class="fas fa-envelope" style="margin-top: 4px;margin-right: 11px;"></i> mail@jjs.com</li>
                        </ul>
                    </div>
                </div>
                <div class="col-12 col-md-6 reachus-box">
                    <h3 class="inner-heading">Send Message</h3>
                    <form id="contactForm" class="row m-0 p-0" action="contact_message_process.php" method="POST">
                        <div class="col-12 form-group ">
                            <div class="col-12 input-from-group rounded">

                                <input type="text" class="form-control" id="cname" name="cname" placeholder="Name">
                            </div>
                        </div>
                        <div class="col-12 form-group ">
                            <div class="col-12 input-from-group rounded">

                                <input type="text" class="form-control" id="cemail" name="cemail" placeholder="Email Id">
                            </div>
                        </div>
                        <div class="col-12 form-group ">
                            <div class="col-12 input-from-group rouned">

                                <input type="text" class="form-control" id="cphone" name="cphone" placeholder="Phone">
                            </div>
                        </div>
                        <div class="col-12 form-group ">
                            <div class="col-12 input-from-group ">
                                <textarea class="form-control msg" rows="4" id="ccomment" name="ccomment" placeholder="Message"></textarea>
                            </div>
                        </div>
                        <div class="col-12 mb-0 form-group text-right mt-4 mt-md-0">
                            <button type="submit" class="main-btn main-btn-white" id="submit">Send</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <? include_once("includes/footer.php"); ?>
</body>

</html>