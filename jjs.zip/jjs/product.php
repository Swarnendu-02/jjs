<!DOCTYPE html>
<html lang="en">
<? include_once("includes/pagesource.php"); ?>

<body>
    <? include_once("includes/header.php"); ?>
    <div class="container-fluid inner-header py-5">
        <div class="container">
            <div class="row">
                <h6>MEET OUR EXPERIENCED</h6>
                <h2 class=" font-weight-bold">Our Dedicated Doctors</h2>
            </div>
        </div>
    </div>
    <div class="container-fluid py-5">
        <div class="container">
            <div class="row">
                <div class="col-3">
                    <ul class="list-group filter-items-box">
                        <li>
                            <button class="filter-btn">Category</button>
                            <ul class="filter-menu">
                                <li class="clear-filter" onclick="clearBrand()">
                                    <i class="fas fa-angle-left"></i> Clear
                                </li>
                                <li>
                                    <label>Genarel <input type="checkbox" class="common_selector brand" value="1">
                                        <span class="checkmark"></span>
                                    </label>
                                </li>
                                <li>
                                    <label>Dental <input type="checkbox" class="common_selector brand" value="1">
                                        <span class="checkmark"></span>
                                    </label>
                                </li>
                            </ul>
                        </li>
                        <li>
                            <button class="filter-btn">Visit Range</button>
                            <ul class="filter-menu">
                                <li class="clear-filter" onclick="clearPrice()">
                                    <i class="fas fa-angle-left"></i> Clear
                                </li>
                                <div>
                                    <input type="number" min="0" max="9900" oninput="validity.valid||(value='0');" id="min_price" class="price-range-field">
                                    <input type="number" min="0" max="10000" oninput="validity.valid||(value='10000');" id="max_price" class="price-range-field" onkeyup="getMaxPrice()">
                                </div>
                            </ul>
                        </li>
                        <li>
                            <button class="filter-btn">Brand</button>
                            <ul class="filter-menu">
                                <li class="clear-filter" onclick="clearBrand()">
                                    <i class="fas fa-angle-left"></i> Clear
                                </li>
                                <li>
                                    <label>Classmate <input type="checkbox" class="common_selector brand" value="1">
                                        <span class="checkmark"></span>
                                    </label>
                                </li>
                            </ul>
                        </li>

                    </ul>
                </div>
                <div class="col-9">
                    <div class="row">
                        <div class="col-4 mb-4">
                            <div class="card border-0 p-3 shadow product-listing" style="border-radius: 0 !important;">
                                <img src="images/dr_ortho_pain_relief_oil_100_ml_0.jpg" alt="Card image cap">
                                <div class="card-body p-0 pt-3 border-top">
                                    <h6 class="card-title inner-title">Dr.Ortho Pain Relief Oil 100 ml</h6>
                                    <p class="price">
                                        <span class="strick-price">
                                            $800 </span>
                                        <span class="main-price">
                                            $850 </span>
                                    </p>
                                    <div class="prd-box-fot">
                                        <div class="quentity-frm">
                                            <input class="cart_counter_1" type="number" min="1" max="10" value="1">
                                        </div>
                                        <button class="add_to_cart" data-cartproductid="1">Add to Cart</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-4 mb-4">
                            <div class="card border-0 p-3 shadow product-listing" style="border-radius: 0 !important;">
                                <img src="images/dr_ortho_pain_relief_oil_100_ml_0.jpg" alt="Card image cap">
                                <div class="card-body p-0 pt-3 border-top">
                                    <h6 class="card-title inner-title">Dr.Ortho Pain Relief Oil 100 ml</h6>
                                    <p class="price">
                                        <span class="strick-price">
                                            $800 </span>
                                        <span class="main-price">
                                            $850 </span>
                                    </p>
                                    <div class="prd-box-fot">
                                        <div class="quentity-frm">
                                            <input class="cart_counter_1" type="number" min="1" max="10" value="1">
                                        </div>
                                        <button class="add_to_cart" data-cartproductid="1">Add to Cart</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-4 mb-4">
                            <div class="card border-0 p-3 shadow product-listing" style="border-radius: 0 !important;">
                                <img src="images/dr_ortho_pain_relief_oil_100_ml_0.jpg" alt="Card image cap">
                                <div class="card-body p-0 pt-3 border-top">
                                    <h6 class="card-title inner-title">Dr.Ortho Pain Relief Oil 100 ml</h6>
                                    <p class="price">
                                        <span class="strick-price">
                                            $800 </span>
                                        <span class="main-price">
                                            $850 </span>
                                    </p>
                                    <div class="prd-box-fot">
                                        <div class="quentity-frm">
                                            <input class="cart_counter_1" type="number" min="1" max="10" value="1">
                                        </div>
                                        <button class="add_to_cart" data-cartproductid="1">Add to Cart</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-4 mb-4">
                            <div class="card border-0 p-3 shadow product-listing" style="border-radius: 0 !important;">
                                <img src="images/dr_ortho_pain_relief_oil_100_ml_0.jpg" alt="Card image cap">
                                <div class="card-body p-0 pt-3 border-top">
                                    <h6 class="card-title inner-title">Dr.Ortho Pain Relief Oil 100 ml</h6>
                                    <p class="price">
                                        <span class="strick-price">
                                            $800 </span>
                                        <span class="main-price">
                                            $850 </span>
                                    </p>
                                    <div class="prd-box-fot">
                                        <div class="quentity-frm">
                                            <input class="cart_counter_1" type="number" min="1" max="10" value="1">
                                        </div>
                                        <button class="add_to_cart" data-cartproductid="1">Add to Cart</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>