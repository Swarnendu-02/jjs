<div class="container-fluid py-5 section-3 position-relative">
    <div class="container">
        <div class="row">
            <div class="col-12 text-center mb-5">
                <h6 class="text-white">PORTFOLIOS</h6>
                <h2 class="mb-0 text-white font-weight-bold">Some of my awesome<br>stuffs here</h2>
            </div>
            <div class="col-12 pl-0">
            <? include_once("includes/porfolio-tab.php"); ?>
            </div>
            <div class="col-12 text-center mt-5">
                <button type="button" class="btn btn-primary btn-sm shadow main-btn">View All</button>
            </div>
        </div>
    </div>
</div>