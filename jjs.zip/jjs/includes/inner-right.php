<div class="col-12 col-md-3">
   <div class="sticky-position">
   <div class="col-12 mb-4">
        <h3 class="inner-heading">Latest Events</h3>
        <div class="col-12 ">
            <div class="blog-card shadow position-relative">
                <div class="blog-image">
                    <img src="images/gallery-grid.jpg" class="h-100 ">
                    <h6>23th Feb, 2021</h6>
                </div>
                <div class="p-3">
                    <div class="content ">
                        <p>All you need to know about JEE Main&amp; Advanced To all the students, aspirants and dreamers! </p>
                    </div>
                    <div class="pt-3 mt-3 border-top card-social">
                        <a class="fb"><i class="fab fa-facebook-f"></i></a>
                        <a class="twttr"><i class="fab fa-twitter"></i></a>
                        <a class="share"><i class="fas fa-share-alt"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-12">
        <h3 class="inner-heading">Latest Press Releases</h3>
        <div class="col-12 ">
            <div class="blog-card shadow position-relative">
                <div class="media-image">
                    <img src="images/istockphoto-623754962-612x612.jpg" class="h-100 ">
                </div>
                <h6 class="p-3">23th Feb, 2021</h6>
                <div class="p-3 pt-0">
                    <div class="content ">
                        <p>All you need to know about JEE Main&amp; Advanced To all the students, aspirants and dreamers! </p>
                    </div>
                    <div class="pt-3 mt-3 border-top card-social">
                        <a class="fb"><i class="fab fa-facebook-f"></i></a>
                        <a class="twttr"><i class="fab fa-twitter"></i></a>
                        <a class="share"><i class="fas fa-share-alt"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
   </div>
</div>