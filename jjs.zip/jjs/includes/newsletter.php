<div class="container-fluid py-5">
    <div class="container position-relative">
        <div class="row">
            <div class="col-md-6 offset-md-3 text-center">
                <div class="col-12">
                    <h6 class="">Newsletter</h6>
                    <h2 class="font-weight-bold mb-4">Always Connected With Us</h2>
                    <p class="mb-4" style="word-break: break-all; ">If you need any medical help we are available for you. Lorem ipsum dolor sit amet, sectetur adipiscing elit, sed do eiusmod tempor the incididunt ut labore et dolore.</p>
                </div>
                <div class="col-12 form-box float-left">
                    <div class="col-12 form-box-label">
                        <label class="fieldlabels">Enter Email Id or Mobile Number</label>

                    </div>
                    <div class="col-12 form-box-input">
                        <input>
                    </div>
                    <div class="col-12 text-center">
                    <button type="submit" class="btn btn-primary btn-sm shadow main-btn">View All</button>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>