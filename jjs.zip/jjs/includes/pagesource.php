<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title>Janani Janashakti Sangathan</title>
	<meta name="author" content="Alvaro Trigo Lopez" />
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="fullPage very simple demo." />
	<meta name="keywords" content="fullpage,jquery,demo,simple" />
	<meta name="Resource-type" content="Document" />
	<link rel="stylesheet" type="text/css" href="bootstrap-5/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="css/responcive.css">
	<link rel="stylesheet" type="text/css" href="dist/fullpage.css" />
	<!-- <link rel="stylesheet" type="text/css" href="examples/examples.css" /> -->
	<link href="css/owl.carousel.min.css?v=2" rel="stylesheet" type="text/css">
	<link href="css/owl.theme.default.min.css?v=2" rel="stylesheet" type="text/css">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">

	<script type="text/javascript" src="dist/fullpage.js"></script>
	<script src="js/jquery.min.js"></script>
	<script src="js/owl.carousel.js"></script>
	<script type="text/javascript">
		var myFullpage = new fullpage('#fullpage', {
			slidesNavigation: true,
			navigation: true,
			menu: '#menu',
			scrollBar: true,
			responsiveWidth: 900,
			afterResponsive: function(isResponsive) {}
		});
	</script>

   
</head>