<div class="container-fluid pb-5 " style="background:#f9fafa; margin-top: -61px; padding-top: 115px !important;">
    <div class="container position-relative">
        <div class="row">
            <div class="col-md-12">
                <div class=" owl-carousel owl-theme ">
                    <div class="item">
                        <img src="images/p-1.png">
                    </div>
                </div>
            </div>

        </div>
    </div>
    <script>
        $('.owl-carousel').owlCarousel({
            autoplay: true,
            autoplayTimeout: 3000,
            autoplayHoverPause: true,
            loop: true,
            lazyLoad: true,
            animateOut: 'slideOutDown',
            animateIn: 'flipInX',
            items: 1,
            margin: 50,
            stagePadding: 30,
            smartSpeed: 450,
            nav: false,
            responsive: {
                0: {
                    items: 1
                },
                600: {
                    items: 1
                },
                1000: {
                    items: 8
                }
            }
        })
    </script>
</div>