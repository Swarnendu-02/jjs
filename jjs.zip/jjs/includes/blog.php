<div class="container-fluid py-xl-5 border-top">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center mb-5">
                    <h2 class="mb-0">Our Blog</h2>
                </div>
                <div class="owl-carousel owl-theme px-3 blog">
                    <div class="item" data-aos="fade-in">
                        <div class="card border-0 pt-3">
                            <img class="card-img-top w-100" src="images/demo.jpg" alt="Card image cap">
                            <div class="card-body">
                                <h4 class="card-title inner-title mb-3">Create Beautiful Website In Less Than An Hour</h4>
                                <h6 class="card-subtitle text-muted mb-4">
                                    <span>Ham Brook • Jan 18, 2019<span> • <span>News<span>
                                </h6>
                                <p class="card-text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Natus eligendi nobis ea maiores sapiente veritatis reprehenderit suscipit quaerat rerum voluptatibus a eius.</p>
                                <a>Continue reading...</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script>
            $('.blog').owlCarousel({
                autoplay: false,
                autoplayTimeout: 2000,
                autoplayHoverPause: true,
                loop: true,
                lazyLoad: true,
                animateOut: 'slideOutDown',
                animateIn: 'flipInX',
                items: 1,
                margin: 40,

                smartSpeed: 450,
                nav: false,
                responsive: {
                    0: {
                        items: 1
                    },
                    600: {
                        items: 1
                    },
                    1000: {
                        items: 3
                    }
                }
            })
        </script>
    </div>