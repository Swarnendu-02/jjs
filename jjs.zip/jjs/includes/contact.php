<div class="container-fluid py-5 ">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center mb-5" style="z-index: 2;">
                <h6>CONTACT US</h6>
                    <h2 class="mb-0 font-weight-bold">Reach out for a new project<br>or just say hello</h2>
                </div>
                <div class="col-12 col-md-7 float-right float-md-left p-5 contact-send-msg" data-aos="fade-up">
                    <div class="col-12 mb-5" style="z-index: 2;">
                        <h6 class="mb-0 text-white">SEND US A MESSAGE</h6>
                    </div>
                    <div class="col-12">
                        <form>
                            <div class="form-group has-float-label mb-4">
                                <input type="text" class="form-control" id="inputAddress" placeholder="Name">
                            </div>
                            <div class="form-group has-float-label mb-4">
                                <input type="text" class="form-control" id="inputAddress" placeholder="Email">
                            </div>
                            <div class="form-group has-float-label mb-4">
                                <input type="text" class="form-control" id="inputAddress" placeholder="Subject">
                            </div>
                            <div class="form-group has-float-label">
                                <textarea type="text" class="form-control mb-4" id="inputAddress" placeholder="Message"></textarea>
                            </div>
                            <div class="form-group">
                                <button type="button" class="btn btn-primary btn-sm  shadow main-btn">Large button</button>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="col-12 col-md-5 float-right float-md-left p-5 " data-aos="fade-down">
                    <div class="col-12 mb-5" style="z-index: 2;">
                        <h6 class="mb-0">CONTACT INFO</h6>
                    </div>
                    <div class="col-12 contact-contact-info">
                        <div class="card border-0 rounded-0 mb-5">
                            <div class="card-body p-0">
                                <h5 class="card-title inner-title"><span class="mr-3"><i class="fas fa-map-marker-alt"></i></span>Innovation</h5>
                                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                            </div>
                        </div>
                        <div class="card border-0 rounded-0 mb-5">
                            <div class="card-body p-0">
                                <h5 class="card-title inner-title"><span class="mr-3"><i class="fas fa-map-marker-alt"></i></span>Innovation</h5>
                                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                            </div>
                        </div>
                        <div class="card border-0 rounded-0 mb-5">
                            <div class="card-body p-0">
                                <h5 class="card-title inner-title"><span class="mr-3"><i class="fas fa-map-marker-alt"></i></span>Innovation</h5>
                                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>