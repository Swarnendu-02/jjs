<div class="container-fluid py-xl-5 section-2">
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-4">
                    <div class="card border-0 bg-transparent">
                        <h6 class="display-1 position-absolute numbering font-weight-bold mb-0 text-white">01</h6>
                        <div class="card-body pl-xl-4 ">
                            <h4 class="card-title inner-title text-white">Innovation</h4>
                            <p class="card-text text-white">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                            <ul class="list-group pl-4">
                                <li class="list-group-item border-0 p-0 mb-3 text-white bg-transparent"><span class="mr-2 text-white"><i class="fas fa-check"></i></span>Cras justo odio</li>
                                <li class="list-group-item border-0 p-0 mb-3 text-white bg-transparent"><span class="mr-2 text-white"><i class="fas fa-check"></i></span>Dapibus ac facilisis in</li>
                                <li class="list-group-item border-0 p-0 mb-3 text-white bg-transparent"><span class="mr-2 text-white"><i class="fas fa-check"></i></span>Morbi leo risus</li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-4">
                    <div class="card border-0 bg-transparent">
                        <h6 class="display-1 position-absolute numbering font-weight-bold mb-0 text-white">01</h6>
                        <div class="card-body pl-xl-4 ">
                            <h4 class="card-title inner-title text-white">Innovation</h4>
                            <p class="card-text text-white">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                            <ul class="list-group pl-4">
                                <li class="list-group-item border-0 p-0 mb-3 text-white bg-transparent"><span class="mr-2 text-white"><i class="fas fa-check"></i></span>Cras justo odio</li>
                                <li class="list-group-item border-0 p-0 mb-3 text-white bg-transparent"><span class="mr-2 text-white"><i class="fas fa-check"></i></span>Dapibus ac facilisis in</li>
                                <li class="list-group-item border-0 p-0 mb-3 text-white bg-transparent"><span class="mr-2 text-white"><i class="fas fa-check"></i></span>Morbi leo risus</li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-4">
                    <div class="card border-0 bg-transparent">
                        <h6 class="display-1 position-absolute numbering font-weight-bold mb-0 text-white">01</h6>
                        <div class="card-body pl-xl-4 ">
                            <h4 class="card-title inner-title text-white">Innovation</h4>
                            <p class="card-text text-white">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                            <ul class="list-group pl-4">
                                <li class="list-group-item border-0 p-0 mb-3 text-white bg-transparent"><span class="mr-2 text-white"><i class="fas fa-check"></i></span>Cras justo odio</li>
                                <li class="list-group-item border-0 p-0 mb-3 text-white bg-transparent"><span class="mr-2 text-white"><i class="fas fa-check"></i></span>Dapibus ac facilisis in</li>
                                <li class="list-group-item border-0 p-0 mb-3 text-white bg-transparent"><span class="mr-2 text-white"><i class="fas fa-check"></i></span>Morbi leo risus</li>
                            </ul>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>