<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<? include_once("includes/pagesource.php"); ?>
</head>

<body class="inner-header">
    <? include_once("includes/header.php"); ?>
    <div class="container-fluid py-3 light-bk">
        <div class="container">
            <div class="row">
                <div class="col-12 breadcrumb">
                    <ol>
                        <li>
                            <a href="index.php">Home</a>
                        </li>
                        <li>
                            Executive Resolution
                        </li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid py-3 py-md-5">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h3 class="inner-heading">Executive Resolution</h3>
                    <div class="owl-carousel owl-theme resolutionyear mb-4">
                        <div class="item">
                            <div class="tablinks occu active-year resolution-year-btn" data-id="2022">
                                2022
                            </div>
                        </div>
                        <div class="item">
                            <div class="tablinks occu resolution-year-btn" data-id="2021">
                                2021
                            </div>
                        </div>
                        <div class="item">
                            <div class="tablinks occu resolution-year-btn" data-id="2020">
                                2020
                            </div>
                        </div>
                    </div>
                    <div class="tabcontent active" data-id="2022">
                        <div class="resolution-content">
                            <div class="resolution-wrap">
                                <h3 class="mb-3">April - Bhubaneswar (Odisha)</h3>
                                <div class="gallery-cell">
                                    <div class="blog-card shadow position-relative">
                                        <div class="media-image">
                                            <img src="images/istockphoto-623754962-612x612.jpg" class="h-100 ">
                                        </div>
                                        <div class="p-3 pt-0">
                                            <div class="content ">
                                                <h4 class="pt-3">Press Releases</h4>
                                            </div>
                                            <div class="pt-3 mt-3 border-top card-social">
                                                <a class="fb"><i class="fab fa-facebook-f"></i></a>
                                                <a class="twttr"><i class="fab fa-twitter"></i></a>
                                                <a class="share"><i class="fas fa-share-alt"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="blog-card shadow position-relative">
                                        <div class="media-image">
                                            <img src="images/istockphoto-623754962-612x612.jpg" class="h-100 ">
                                        </div>
                                        <div class="p-3 pt-0">
                                            <div class="content ">
                                                <h4 class="pt-3">Press Releases</h4>
                                            </div>
                                            <div class="pt-3 mt-3 border-top card-social">
                                                <a class="fb"><i class="fab fa-facebook-f"></i></a>
                                                <a class="twttr"><i class="fab fa-twitter"></i></a>
                                                <a class="share"><i class="fas fa-share-alt"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="resolution-wrap">
                                <h3 class="mb-3">April - Bhubaneswar (Odisha)</h3>
                                <div class="gallery-cell">
                                    <div class="blog-card shadow position-relative">
                                        <div class="media-image">
                                            <img src="images/istockphoto-623754962-612x612.jpg" class="h-100 ">
                                        </div>
                                        <div class="p-3 pt-0">
                                            <div class="content ">
                                                <h4 class="pt-3">Press Releases</h4>
                                            </div>
                                            <div class="pt-3 mt-3 border-top card-social">
                                                <a class="fb"><i class="fab fa-facebook-f"></i></a>
                                                <a class="twttr"><i class="fab fa-twitter"></i></a>
                                                <a class="share"><i class="fas fa-share-alt"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="blog-card shadow position-relative">
                                        <div class="media-image">
                                            <img src="images/istockphoto-623754962-612x612.jpg" class="h-100 ">
                                        </div>
                                        <div class="p-3 pt-0">
                                            <div class="content ">
                                                <h4 class="pt-3">Press Releases</h4>
                                            </div>
                                            <div class="pt-3 mt-3 border-top card-social">
                                                <a class="fb"><i class="fab fa-facebook-f"></i></a>
                                                <a class="twttr"><i class="fab fa-twitter"></i></a>
                                                <a class="share"><i class="fas fa-share-alt"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tabcontent active" data-id="2021">
                        <div class="resolution-content">
                            <div class="resolution-wrap">
                                <h3 class="mb-3">April - Bhubaneswar (Odisha)</h3>
                                <div class="gallery-cell">
                                    <div class="blog-card shadow position-relative">
                                        <div class="media-image">
                                            <img src="images/istockphoto-623754962-612x612.jpg" class="h-100 ">
                                        </div>
                                        <div class="p-3 pt-0">
                                            <div class="content ">
                                                <h4 class="pt-3">Press Releases</h4>
                                            </div>
                                            <div class="pt-3 mt-3 border-top card-social">
                                                <a class="fb"><i class="fab fa-facebook-f"></i></a>
                                                <a class="twttr"><i class="fab fa-twitter"></i></a>
                                                <a class="share"><i class="fas fa-share-alt"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="blog-card shadow position-relative">
                                        <div class="media-image">
                                            <img src="images/istockphoto-623754962-612x612.jpg" class="h-100 ">
                                        </div>
                                        <div class="p-3 pt-0">
                                            <div class="content ">
                                                <h4 class="pt-3">Press Releases</h4>
                                            </div>
                                            <div class="pt-3 mt-3 border-top card-social">
                                                <a class="fb"><i class="fab fa-facebook-f"></i></a>
                                                <a class="twttr"><i class="fab fa-twitter"></i></a>
                                                <a class="share"><i class="fas fa-share-alt"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="resolution-wrap">
                                <h3 class="mb-3">April - Bhubaneswar (Odisha)</h3>
                                <div class="gallery-cell">
                                    <div class="blog-card shadow position-relative">
                                        <div class="media-image">
                                            <img src="images/istockphoto-623754962-612x612.jpg" class="h-100 ">
                                        </div>
                                        <div class="p-3 pt-0">
                                            <div class="content ">
                                                <h4 class="pt-3">Press Releases</h4>
                                            </div>
                                            <div class="pt-3 mt-3 border-top card-social">
                                                <a class="fb"><i class="fab fa-facebook-f"></i></a>
                                                <a class="twttr"><i class="fab fa-twitter"></i></a>
                                                <a class="share"><i class="fas fa-share-alt"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="blog-card shadow position-relative">
                                        <div class="media-image">
                                            <img src="images/istockphoto-623754962-612x612.jpg" class="h-100 ">
                                        </div>
                                        <div class="p-3 pt-0">
                                            <div class="content ">
                                                <h4 class="pt-3">Press Releases</h4>
                                            </div>
                                            <div class="pt-3 mt-3 border-top card-social">
                                                <a class="fb"><i class="fab fa-facebook-f"></i></a>
                                                <a class="twttr"><i class="fab fa-twitter"></i></a>
                                                <a class="share"><i class="fas fa-share-alt"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="resolution-wrap">
                                <h3 class="mb-3">April - Bhubaneswar (Odisha)</h3>
                                <div class="gallery-cell">
                                    <div class="blog-card shadow position-relative">
                                        <div class="media-image">
                                            <img src="images/istockphoto-623754962-612x612.jpg" class="h-100 ">
                                        </div>
                                        <div class="p-3 pt-0">
                                            <div class="content ">
                                                <h4 class="pt-3">Press Releases</h4>
                                            </div>
                                            <div class="pt-3 mt-3 border-top card-social">
                                                <a class="fb"><i class="fab fa-facebook-f"></i></a>
                                                <a class="twttr"><i class="fab fa-twitter"></i></a>
                                                <a class="share"><i class="fas fa-share-alt"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="blog-card shadow position-relative">
                                        <div class="media-image">
                                            <img src="images/istockphoto-623754962-612x612.jpg" class="h-100 ">
                                        </div>
                                        <div class="p-3 pt-0">
                                            <div class="content ">
                                                <h4 class="pt-3">Press Releases</h4>
                                            </div>
                                            <div class="pt-3 mt-3 border-top card-social">
                                                <a class="fb"><i class="fab fa-facebook-f"></i></a>
                                                <a class="twttr"><i class="fab fa-twitter"></i></a>
                                                <a class="share"><i class="fas fa-share-alt"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tabcontent active" data-id="2020">
                        <div class="resolution-content">

                            <div class="resolution-wrap">
                                <h3 class="mb-3">April - Bhubaneswar (Odisha)</h3>
                                <div class="gallery-cell">
                                    <div class="blog-card shadow position-relative">
                                        <div class="media-image">
                                            <img src="images/istockphoto-623754962-612x612.jpg" class="h-100 ">
                                        </div>
                                        <div class="p-3 pt-0">
                                            <div class="content ">
                                                <h4 class="pt-3">Press Releases</h4>
                                            </div>
                                            <div class="pt-3 mt-3 border-top card-social">
                                                <a class="fb"><i class="fab fa-facebook-f"></i></a>
                                                <a class="twttr"><i class="fab fa-twitter"></i></a>
                                                <a class="share"><i class="fas fa-share-alt"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="blog-card shadow position-relative">
                                        <div class="media-image">
                                            <img src="images/istockphoto-623754962-612x612.jpg" class="h-100 ">
                                        </div>
                                        <div class="p-3 pt-0">
                                            <div class="content ">
                                                <h4 class="pt-3">Press Releases</h4>
                                            </div>
                                            <div class="pt-3 mt-3 border-top card-social">
                                                <a class="fb"><i class="fab fa-facebook-f"></i></a>
                                                <a class="twttr"><i class="fab fa-twitter"></i></a>
                                                <a class="share"><i class="fas fa-share-alt"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
    <? include_once("includes/footer.php"); ?>
</body>
<script>
    $('.resolutionyear').owlCarousel({
        loop: false,
        margin: 5,
        nav: true,
        dots: false,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 1
            },
            1000: {
                items: 11
            }
        }
    })
</script>
<script>
    $(document).ready(function() {
        $('.tablinks').click(function() {
            $(".tabcontent").removeClass('active');
            $(".tabcontent[data-id='" + $(this).attr('data-id') + "']").addClass("active");
            $(".tablinks").removeClass('active-year');
            $(this).parent().find(".tablinks").addClass('active-year');
        });
    });
</script>

</html>