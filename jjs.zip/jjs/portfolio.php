<!DOCTYPE html>
<html lang="en">
<? include_once("includes/pagesource.php"); ?>

<body>
    <? include_once("includes/header.php"); ?>

    <div class="container-fluid py-5">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center mb-5">
                    <h6>PORTFOLIOS</h6>
                    <h2 class="mb-0 font-weight-bold display-4">All of my awesome<br>stuffs here</h2>
                </div>
                <? include_once("includes/porfolio-tab.php"); ?>
                
            </div>
        </div>
    </div>
    <? include_once("includes/footer.php"); ?>
</body>

</html>