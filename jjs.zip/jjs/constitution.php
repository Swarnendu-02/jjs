<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<? include_once("includes/pagesource.php"); ?>
</head>

<body class="inner-header">
    <? include_once("includes/header.php"); ?>
    <div class="container-fluid py-3 light-bk">
        <div class="container">
            <div class="row">
                <div class="col-12 breadcrumb">
                    <ol>
                        <li>
                            <a href="index.php">Home</a>
                        </li>
                        <li>
                            Constitution
                        </li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid py-3 py-md-5">
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-9">
                    <h3 class="inner-heading">Constitution</h3>
                    <div class="d-flex ">
                        <div class="constitution-wrap mr-md-2">
                            <div class="constitution-cell py-5 px-3">
                                <p>Constitution and Rules</p>
                                <img src="images/logo.png">
                            </div>
                            <div class="p-3 border-top card-social">
                                <a class="fb"><i class="fab fa-facebook-f"></i></a>
                                <a class="twttr"><i class="fab fa-twitter"></i></a>
                                <a class="share"><i class="fas fa-share-alt"></i></a>
                            </div>
                        </div>
                        <div class="constitution-wrap ml-md-2">
                            <div class="constitution-cell py-5 px-3">
                                <p>Constitution and Rules</p>
                                <img src="images/logo.png">
                            </div>
                            <div class="p-3 border-top card-social">
                                <a class="fb"><i class="fab fa-facebook-f"></i></a>
                                <a class="twttr"><i class="fab fa-twitter"></i></a>
                                <a class="share"><i class="fas fa-share-alt"></i></a>
                            </div>
                        </div>
                    </div>

               
            </div>
            <? include_once("includes/inner-right.php"); ?>
        </div>
    </div>
    </div>
    <? include_once("includes/footer.php"); ?>
</body>

</html>