<!DOCTYPE html>
<html lang="en">
<? include_once("includes/pagesource.php"); ?>

<body>
    <? include_once("includes/header.php"); ?>
    <div class="container-fluid py-3 light-bk">
        <div class="container">
            <div class="row">
                <div class="col-12 breadcrumb">
                    <ol>
                        <li>
                            <a href="index.php">Home</a>
                        </li>
                        <li>
                            Join JJS
                        </li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <style>
        .reachus-box .input-from-group {
 
  padding: 0;
  margin-bottom: 15px;
}

.reachus-box .form-group input {
  height: 55px;
  border-bottom: 2px solid #000;
  width: 100%;
  padding: 22px;
  border: none;
  border-bottom: 0;
  border-radius: 0.25rem;
    border: 2px solid;
}

.reachus-box .form-group textarea {
  height: 55px;
  border-bottom: 2px solid #000;
  width: 100%;
  padding: 22px;
  border: none;
  border-bottom: 0;
  height: 150px;
  border-radius: 0.25rem;
    border: 2px solid;
}

.reachus-box .form-group .input-label {
  margin: 0;
  width: 12%;
  border-right: 2px solid #123a68;
  color: #123a68;
}

.reach-us {
  background: white;
  padding: 50px 0;
}

.reach-us-box {
  padding: 0;
}
.addbox ul{
    margin-bottom: 0;
    margin-left: 0;
    padding: 0;
}
.addbox li{
    list-style: none;
    font-size: 16px;
    display: flex;
    margin-bottom: 15px;
}
.addbox li:last-child{
    margin-bottom: 0px;
}
.reachus-box button
{
    display: inline-block;
    /* color: #fff !important; */
    font-size: 18px;
    transition: .5s;
    border: 0;
       padding: 15px 50px;
    background: black;
    color: white;
  
}
.reachus-box label{
    margin-bottom: 10px;
    font-weight: bold;
}
    </style>
    <div class="container-fluid py-3">
        <div class="container">
            <div class="row">
          
                <div class="col-12 col-md-6 offset-md-3 reachus-box">
                    <h3 class="inner-heading">Join JJS</h3>
                    <form id="contactForm" class="row m-0 p-0" action="contact_message_process.php" method="POST">
                        <div class="col-12 form-group ">
                            <div class="col-12 input-from-group rounded">
                                <label>Name</label>
                                <input type="text" class="form-control" id="cname" name="cname" >
                            </div>
                        </div>
                        <div class="col-12 form-group ">
                            <div class="col-12 input-from-group rounded">
                            <label>Email</label>
                                <input type="text" class="form-control" id="cemail" name="cemail" >
                            </div>
                        </div>
                        <div class="col-12 form-group ">
                            <div class="col-12 input-from-group rouned">
                            <label>Phone</label>
                                <input type="text" class="form-control" id="cphone" name="cphone" >
                            </div>
                        </div>
                        <div class="col-12 form-group ">
                            <div class="col-12 input-from-group rouned">
                            <label>DOB</label>
                                <input type="date" class="form-control" id="cphone" name="cphone" ">
                            </div>
                        </div>
                        <div class="col-12 form-group ">
                            <div class="col-12 input-from-group rouned">
                            <label>Home Address</label>
                                <input type="type" class="form-control" id="cphone" name="cphone" >
                            </div>
                        </div>
                        <div class="col-12 form-group ">
                            <div class="col-12 input-from-group rouned">
                            <label>State</label>
                                <input type="type" class="form-control" id="cphone" name="cphone" >
                            </div>
                        </div>
                        <div class="col-12 form-group ">
                            <div class="col-12 input-from-group rouned">
                            <label>District</label>
                                <input type="type" class="form-control" id="cphone" name="cphone" >
                            </div>
                        </div>
                        <div class="col-12 form-group ">
                            <div class="col-12 input-from-group rouned">
                            <label>Pin Code</label>
                                <input type="type" class="form-control" id="cphone" name="cphone" >
                            </div>
                        </div>
                        
                        <div class="col-12 mb-0 form-group text-right mt-4 mt-md-0">
                            <button type="submit" class="main-btn main-btn-white" id="submit">Confirm</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <? include_once("includes/footer.php"); ?>
</body>

</html>