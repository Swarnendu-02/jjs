<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<? include_once("includes/pagesource.php"); ?>
</head>

<body class="inner-header">
    <? include_once("includes/header.php"); ?>
    <div class="container-fluid py-3 light-bk">
        <div class="container">
            <div class="row">
                <div class="col-12 breadcrumb">
                    <ol>
                        <li>
                            <a href="index.php">Home</a>
                        </li>
                        <li>
                            Interviews
                        </li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid py-3 py-md-5">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="col-12 gallery-cell ">
                        <div class="blog-card shadow position-relative">
                            <div class="blog-image">
                                <img src="images/burnett-kelly_custom-d08bbabb52c17d9f888ccd374364f265b1e9384b-s1100-c50.jpg" class="h-100 ">
                                <h6>23th Feb, 2021</h6>
                            </div>
                            <div class="p-3">
                                <div class="content ">
                                    <p>All you need to know about JEE Main&amp; Advanced To all the students, aspirants and dreamers! </p>
                                </div>
                                <div class="pt-3 mt-3 border-top card-social">
                                    <a class="fb"><i class="fab fa-facebook-f"></i></a>
                                    <a class="twttr"><i class="fab fa-twitter"></i></a>
                                    <a class="share"><i class="fas fa-share-alt"></i></a>
                                </div>
                            </div>
                        </div>
                        <div class="blog-card shadow position-relative">
                            <div class="blog-image">
                                <img src="images/p076s78l.jpg" class="h-100 ">
                                <h6>23th Feb, 2021</h6>
                            </div>
                            <div class="p-3">
                                <div class="content ">
                                    <p>All you need to know about JEE Main&amp; Advanced To all the students, aspirants and dreamers! </p>
                                </div>
                                <div class="pt-3 mt-3 border-top card-social">
                                    <a class="fb"><i class="fab fa-facebook-f"></i></a>
                                    <a class="twttr"><i class="fab fa-twitter"></i></a>
                                    <a class="share"><i class="fas fa-share-alt"></i></a>
                                </div>
                            </div>
                        </div>
                        <div class="blog-card shadow position-relative">
                            <div class="blog-image">
                                <img src="images/Interview.jpg" class="h-100 ">
                                <h6>23th Feb, 2021</h6>
                            </div>
                            <div class="p-3">
                                <div class="content ">
                                    <p>All you need to know about JEE Main&amp; Advanced To all the students, aspirants and dreamers! </p>
                                </div>
                                <div class="pt-3 mt-3 border-top card-social">
                                    <a class="fb"><i class="fab fa-facebook-f"></i></a>
                                    <a class="twttr"><i class="fab fa-twitter"></i></a>
                                    <a class="share"><i class="fas fa-share-alt"></i></a>
                                </div>
                            </div>
                        </div>
                        <div class="blog-card shadow position-relative">
                            <div class="blog-image">
                                <img src="images/politician_interview.jpg" class="h-100 ">
                                <h6>23th Feb, 2021</h6>
                            </div>
                            <div class="p-3">
                                <div class="content ">
                                    <p>All you need to know about JEE Main&amp; Advanced To all the students, aspirants and dreamers! </p>
                                </div>
                                <div class="pt-3 mt-3 border-top card-social">
                                    <a class="fb"><i class="fab fa-facebook-f"></i></a>
                                    <a class="twttr"><i class="fab fa-twitter"></i></a>
                                    <a class="share"><i class="fas fa-share-alt"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <? include_once("includes/footer.php"); ?>
</body>

</html>