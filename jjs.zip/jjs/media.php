<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<? include_once("includes/pagesource.php"); ?>
</head>

<body class="inner-header">
    <? include_once("includes/header.php"); ?>
    <div class="container-fluid py-3 light-bk">
        <div class="container">
            <div class="row">
                <div class="col-12 breadcrumb">
                    <ol>
                        <li>
                            <a href="index.php">Home</a>
                        </li>
                        <li>
                            Media
                        </li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid py-3 py-md-5">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="tab mb-5">
                        <button class="tablinks mr-3 active" onclick="openCity(event, 'London')">Press Releases</button>
                        <button class="tablinks mr-3" onclick="openCity(event, 'Paris')">Articles</button>
                        <button class="tablinks" onclick="openCity(event, 'Tokyo')">Speeches</button>
                    </div>
                    <div id="London" class="tabcontent" style="display: block;">
                        <div class="col-12 gallery-cell ">
                            <div class="blog-card shadow position-relative">
                                <div class="media-image">
                                    <img src="images/istockphoto-623754962-612x612.jpg" class="h-100 ">
                                </div>
                                <h6 class="p-3">23th Feb, 2021</h6>
                                <div class="p-3 pt-0">
                                    <div class="content ">
                                        <p>All you need to know about JEE Main&amp; Advanced To all the students, aspirants and dreamers! </p>
                                    </div>
                                    <div class="pt-3 mt-3 border-top card-social">
                                        <a class="fb"><i class="fab fa-facebook-f"></i></a>
                                        <a class="twttr"><i class="fab fa-twitter"></i></a>
                                        <a class="share"><i class="fas fa-share-alt"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div id="Paris" class="tabcontent">
                        <div class="col-12 gallery-cell ">
                            <div class="blog-card shadow position-relative">
                                <div class="media-image">
                                    <img src="images/gallery-grid.jpg" class="h-100 ">
                                </div>
                                <h6 class="p-3">23th Feb, 2021</h6>
                                <div class="p-3 pt-0">
                                    <div class="content ">
                                        <p>All you need to know about JEE Main&amp; Advanced To all the students, aspirants and dreamers! </p>
                                    </div>
                                    <div class="pt-3 mt-3 border-top card-social">
                                        <a class="fb"><i class="fab fa-facebook-f"></i></a>
                                        <a class="twttr"><i class="fab fa-twitter"></i></a>
                                        <a class="share"><i class="fas fa-share-alt"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div id="Tokyo" class="tabcontent">
                        <div class="col-12 gallery-cell ">
                            <div class="blog-card shadow position-relative">
                                <div class="media-image">
                                    <img src="images/gallery-grid.jpg" class="h-100 ">
                                </div>
                                <h6 class="p-3">23th Feb, 2021</h6>
                                <div class="p-3 pt-0">
                                    <div class="content ">
                                        <p>All you need to know about JEE Main&amp; Advanced To all the students, aspirants and dreamers! </p>
                                    </div>
                                    <div class="pt-3 mt-3 border-top card-social">
                                        <a class="fb"><i class="fab fa-facebook-f"></i></a>
                                        <a class="twttr"><i class="fab fa-twitter"></i></a>
                                        <a class="share"><i class="fas fa-share-alt"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <script>
                        function openCity(evt, cityName) {
                            var i, tabcontent, tablinks;
                            tabcontent = document.getElementsByClassName("tabcontent");
                            for (i = 0; i < tabcontent.length; i++) {
                                tabcontent[i].style.display = "none";
                            }
                            tablinks = document.getElementsByClassName("tablinks");
                            for (i = 0; i < tablinks.length; i++) {
                                tablinks[i].className = tablinks[i].className.replace(" active", "");
                            }
                            document.getElementById(cityName).style.display = "block";
                            evt.currentTarget.className += " active";
                        }
                    </script>
                </div>
            </div>
        </div>
    </div>
    <? include_once("includes/footer.php"); ?>
</body>

</html>