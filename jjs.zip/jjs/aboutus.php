<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<? include_once("includes/pagesource.php"); ?>
</head>

<body class="inner-header">
    <? include_once("includes/header.php"); ?>
    <div class="container-fluid py-3 light-bk">
        <div class="container">
            <div class="row">
                <div class="col-12 breadcrumb">
                    <ol>
                        <li>
                            <a href="index.php">Home</a>
                        </li>
                        <li>
                        About US
                        </li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid py-3 py-md-5">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h3 class="inner-heading">About US</h3>
                    <div class="content">
                        <p>
                            Given the cost, the project has been opened to "class sponsoring" from any class willing to pitch in. A class that contributes $100,000 to the project will be recognized at dedication and the memorial will be engraved with the class year (in an out of the way corner that does not detract from the memorial's overall message)., Erick Cinquemani Aenean ultricies mi vitae est. Mauris placerat eleifend leo. Quisque sit amet est et sapien ullamcorper pharetra. Vestibulum erat wisi, condimentum sed.
                        </p>
                        <p>
                            As many of you know the Class of '67 is spearheading an effort to create a War Memorial on campus. The monument will be dedicated in 2017 to coincide with The Citadel's 175th anniversary. The $1,000,000+ overall project cost will support both construction as well as the creation of an endowment to maintain the memorial’s upkeep in perpetuity.
                        </p>
                        <p>
                            Given the cost, the project has been opened to "class sponsoring" from any class willing to pitch in. A class that contributes $100,000 to the project will be recognized at dedication and the memorial will be engraved with the class year (in an out of the way corner that does not detract from the memorial's overall message)., Erick Cinquemani Aenean ultricies mi vitae est. Mauris placerat eleifend leo. Quisque sit amet est et sapien ullamcorper pharetra. Vestibulum erat wisi, condimentum sed.
                        </p>
                        <p>
                            As many of you know the Class of '67 is spearheading an effort to create a War Memorial on campus. The monument will be dedicated in 2017 to coincide with The Citadel's 175th anniversary. The $1,000,000+ overall project cost will support both construction as well as the creation of an endowment to maintain the memorial’s upkeep in perpetuity.
                        </p>
                        <p>
                            Given the cost, the project has been opened to "class sponsoring" from any class willing to pitch in. A class that contributes $100,000 to the project will be recognized at dedication and the memorial will be engraved with the class year (in an out of the way corner that does not detract from the memorial's overall message)., Erick Cinquemani Aenean ultricies mi vitae est. Mauris placerat eleifend leo. Quisque sit amet est et sapien ullamcorper pharetra. Vestibulum erat wisi, condimentum sed.
                        </p>
                        <p>
                            As many of you know the Class of '67 is spearheading an effort to create a War Memorial on campus. The monument will be dedicated in 2017 to coincide with The Citadel's 175th anniversary. The $1,000,000+ overall project cost will support both construction as well as the creation of an endowment to maintain the memorial’s upkeep in perpetuity.
                        </p>
                        <p>
                            Given the cost, the project has been opened to "class sponsoring" from any class willing to pitch in. A class that contributes $100,000 to the project will be recognized at dedication and the memorial will be engraved with the class year (in an out of the way corner that does not detract from the memorial's overall message)., Erick Cinquemani Aenean ultricies mi vitae est. Mauris placerat eleifend leo. Quisque sit amet est et sapien ullamcorper pharetra. Vestibulum erat wisi, condimentum sed.
                        </p>
                        <p>
                            As many of you know the Class of '67 is spearheading an effort to create a War Memorial on campus. The monument will be dedicated in 2017 to coincide with The Citadel's 175th anniversary. The $1,000,000+ overall project cost will support both construction as well as the creation of an endowment to maintain the memorial’s upkeep in perpetuity.
                        </p>
                    </div>
                    <div class="col-12 about-gallery-cell">
                        <img src="images/gallery-grid.jpg" class="gallery-img">
                        <img src="images/gallery-grid.jpg" class="gallery-img">
                        <img src="images/gallery-grid.jpg" class="gallery-img">
                    </div>
                </div>
                <? include_once("includes/inner-right.php"); ?>
            </div>
        </div>
    </div>
    <? include_once("includes/footer.php"); ?>
</body>

</html>