<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<? include_once("includes/pagesource.php"); ?>
</head>

<body class="inner-header">
    <? include_once("includes/header.php"); ?>
    <div class="container-fluid py-3 light-bk">
        <div class="container">
            <div class="row">
                <div class="col-12 breadcrumb">
                    <ol>
                        <li>
                            <a href="index.php">Home</a>
                        </li>
                        <li>
                            Presidents
                        </li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid p-0 prs-banner-cell">
        <img src="images/history-in-hd-DhwKbmdlJa0-unsplash (1).jpg" class="prs-banner">
        <div class="banner-content-cell">
            <div class="banner-content-wrap">
                <h2>Leader 1</h2>
                <h4>29th Jun, 1994 - 8th Aug, 1999</h4>
            </div>
        </div>
    </div>
    <div class="container-fluid py-3 py-md-5">
        <div class="container">
            <div class="row">
                <div class="col-12 mb-3 mb-md-5">
                    <h3 class="prs-heading border-0">Leader 1</h3>
                    <div class="content">
                        <p>
                            Given the cost, the project has been opened to "class sponsoring" from any class willing to pitch in. A class that contributes $100,000 to the project will be recognized at dedication and the memorial will be engraved with the class year (in an out of the way corner that does not detract from the memorial's overall message)., Erick Cinquemani Aenean ultricies mi vitae est. Mauris placerat eleifend leo. Quisque sit amet est et sapien ullamcorper pharetra. Vestibulum erat wisi, condimentum sed.
                        </p>
                        <p>
                            As many of you know the Class of '67 is spearheading an effort to create a War Memorial on campus. The monument will be dedicated in 2017 to coincide with The Citadel's 175th anniversary. The $1,000,000+ overall project cost will support both construction as well as the creation of an endowment to maintain the memorial’s upkeep in perpetuity.
                        </p>
                    </div>
                </div>
                <div class="col-12">
                    <h3 class="inner-heading">POSITIONS HELD</h3>
                    <div class="content">
                        <p><strong>1994</strong> - Founder-Member, Janani Janashakti Sangathan</p>
                        <p><strong>1995</strong> - Given the cost, the project has been opened</p>
                        <p><strong>1996</strong> - As many of you know the Class of '67 is spearheading an effort to create</p>
                        <p><strong>1997</strong> - Given the cost, the project has been opened</p>
                        <p><strong>1998</strong> - As many of you know the Class of '67 is spearheading an effort to create</p>
                        <p><strong>1999</strong> - Given the cost, the project has been opened</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid py-3 py-md-5 light-bk">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h3 class="inner-heading">Gallery</h3>
                    <div class="col-12 gallery-cell">
                        <img src="images/gallery-grid.jpg" class="gallery-img">
                        <img src="images/gallery-grid.jpg" class="gallery-img">
                        <img src="images/gallery-grid.jpg" class="gallery-img">
                        <img src="images/gallery-grid.jpg" class="gallery-img">
                        <img src="images/gallery-grid.jpg" class="gallery-img">
                        <img src="images/gallery-grid.jpg" class="gallery-img">
                        <img src="images/gallery-grid.jpg" class="gallery-img">
                        <img src="images/gallery-grid.jpg" class="gallery-img">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <? include_once("includes/footer.php"); ?>
</body>

</html>