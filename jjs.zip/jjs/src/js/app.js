import './polyfills/index.js';
export { default } from './fullpage.js';
import './easing.js';
import './jquery-adaptor.js';