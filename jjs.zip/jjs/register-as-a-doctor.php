<!DOCTYPE html>
<html lang="en">
<? include_once("includes/pagesource.php"); ?>

<body>
    <? include_once("includes/header.php"); ?>
    <div class="container-fluid inner-header py-5">
        <div class="container">
            <div class="row">
                <h6>Registration</h6>
                <h2 class=" font-weight-bold">Register As A Doctor</h2>
            </div>
        </div>
    </div>
    <div class="container-fluid">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <form id="msform">
                            <!-- progressbar -->
                            <ul id="progressbar" class="py-5 px-0">
                                <li class="active" id="account"><strong>Personal Information</strong></li>
                                <li id="personal"><strong>Professional Details</strong></li>
                                <li id="payment"><strong>Chamber Details</strong></li>
                                <li id="payment"><strong>Profile Details</strong></li>
                                <li id="payment"><strong>Additional Information</strong></li>
                                <li id="payment"><strong>Preview</strong></li>
                            </ul>
                            
                            <fieldset>
                                <div class="form-card">
                                    <div class="row">
                                        <div class="col-4 form-box float-left">
                                            <div class="col-12 form-box-label">
                                                <label class="fieldlabels">First Name: <span class="requered-field">*</span></label>

                                            </div>
                                            <div class="col-12 form-box-input">
                                                <input>
                                            </div>

                                            <span class="error">Please Fill</span>
                                        </div>
                                        <div class="col-4 form-box float-left">
                                            <div class="col-12 form-box-label">
                                                <label class="fieldlabels">Middle Name:</label>
                                            </div>
                                            <div class="form-box-input">
                                                <input>
                                            </div>

                                        </div>
                                        <div class="col-4 form-box float-left">
                                            <div class="col-12 form-box-label">
                                                <label class="fieldlabels">Last Name: <span class="requered-field">*</span></label>
                                            </div>
                                            <div class="form-box-input">
                                                <input>
                                            </div>
                                            <span class="error">Please Fill</span>
                                        </div>
                                        <div class="col-3 form-box float-left">
                                            <div class="col-12 form-box-label">
                                                <label class="fieldlabels">Location: <span class="requered-field">*</span></label>
                                            </div>
                                            <div class="form-box-input">
                                                <input>
                                            </div>
                                            <span class="error">Please Fill</span>
                                        </div>
                                        <div class="col-3 form-box float-left">
                                            <div class="col-12 form-box-label">
                                                <label class="fieldlabels">City: <span class="requered-field">*</span></label>
                                            </div>
                                            <div class="form-box-input">
                                                <input>
                                            </div>
                                            <span class="error">Please Fill</span>
                                        </div>
                                        <div class="col-3 form-box float-left">
                                            <div class="col-12 form-box-label">
                                                <label class="fieldlabels">State: <span class="requered-field">*</span></label>
                                            </div>
                                            <div class="form-box-input">
                                                <input>
                                            </div>
                                            <span class="error">Please Fill</span>
                                        </div>
                                        <div class="col-3 form-box float-left">
                                            <div class="col-12 form-box-label">
                                                <label class="fieldlabels">ZIP Code: <span class="requered-field">*</span></label>
                                            </div>
                                            <div class="form-box-input">
                                                <input>
                                            </div>
                                            <span class="error">Please Fill</span>
                                        </div>
                                        <div class="col-6 form-box float-left">
                                            <div class="col-12 form-box-label">
                                                <label class="fieldlabels">Contact Number: <span class="requered-field">*</span></label>
                                                <span class="verified float-right"><i class="fas fa-check-circle"></i> Verified</span>
                                                <span class="verify float-right" onclick="openverification()" style="display: none;">Verify</span>
                                            </div>
                                            <div class="col-12 form-box-input">
                                                <p class="number-code">+91</p>
                                                <input>
                                            </div>
                                            <span class="error">Please Fill</span>
                                        </div>
                                        <div class="col-6 form-box float-left">
                                            <div class="col-12 form-box-label">
                                                <label class="fieldlabels">Email Id: <span class="requered-field">*</span></label>
                                                <span class="verified float-right" style="display: none;"><i class="fas fa-check-circle"></i> Verified</span>
                                                <span class="verify float-right" onclick="openverification()">Verify</span>
                                            </div>
                                            <div class="col-12 form-box-input">
                                                <input>
                                            </div>
                                            <span class="error">Please Fill</span>
                                        </div>
                                        <div class="col-4 form-box float-left">
                                            <div class="col-12 form-box-label">
                                                <label class="fieldlabels">User Id: <span class="requered-field">*</span></label>
                                            </div>
                                            <div class="col-12 form-box-input">
                                                <select>
                                                    <option>Select An Option</option>
                                                    <option>Contact Number</option>
                                                    <option>Email Id</option>
                                                </select>
                                            </div>
                                            <span class="error">Please Fill</span>
                                        </div>
                                        <div class="col-4 form-box float-left">
                                            <div class="col-12 form-box-label">
                                                <label class="fieldlabels">Password: <span class="requered-field">*</span></label>
                                                <span class="pass-week float-right" style="display: none;">Week</span>
                                                <span class="pass-strong float-right">Strong</span>
                                            </div>
                                            <div class="col-12 form-box-input">
                                                <p class="number-code"><span style="display: none;"><i class="fas fa-eye"></i></span><span><i class="fas fa-eye-slash"></i></span></p>
                                                <input>
                                            </div>
                                            <span class="error">Please Fill</span>
                                        </div>
                                        <div class="col-4 form-box float-left">
                                            <div class="col-12 form-box-label">
                                                <label class="fieldlabels">Confirm Password: <span class="requered-field">*</span></label>
                                                <span class="pass-week float-right">Week</span>
                                                <span class="pass-strong float-right" style="display: none;">Strong</span>
                                            </div>
                                            <div class="col-12 form-box-input">
                                                <p class="number-code"><span><i class="fas fa-eye"></i></span><span style="display: none;"><i class="fas fa-eye-slash"></i></span></p>
                                                <input>
                                            </div>
                                            <span class="error">Please Fill</span>
                                        </div>
                                    </div>
                                </div>
                                <input type="button" name="next" class="next action-button" value="Next" />
                            </fieldset>
                            <fieldset>
                                <div class="form-card">
                                    <div class="row">
                                        <div class="col-12">
                                            <h3 class="fs-title">Total Experience</h3>
                                        </div>
                                        <div class="col-6 form-box float-left">
                                            <div class="col-12 form-box-label">
                                                <label class="fieldlabels">Years: <span class="requered-field">*</span></label>
                                            </div>
                                            <div class="col-12 form-box-input">
                                                <input>
                                            </div>
                                            <span class="error">Please Fill</span>
                                        </div>
                                        <div class="col-6 form-box float-left">
                                            <div class="col-12 form-box-label">
                                                <label class="fieldlabels">Months:</label>
                                            </div>
                                            <div class="form-box-input">
                                                <input>
                                            </div>
                                        </div>
                                        <div class="col-12 prf-more-sec">
                                            <div class="col-12">
                                                <h3 class="fs-title">Educatinal Information</h3>
                                            </div>
                                            <div class="row">
                                                <div class="col-4 form-box float-left">
                                                    <div class="col-12 form-box-label">
                                                        <label class="fieldlabels">Degree: <span class="requered-field">*</span></label>
                                                    </div>
                                                    <div class="form-box-input">
                                                        <select>
                                                            <option>Select An Option</option>
                                                            <option>Degree</option>
                                                            <option>Degree</option>
                                                        </select>
                                                    </div>
                                                    <span class="error">Please Fill</span>
                                                </div>
                                                <div class="col-4 form-box float-left">
                                                    <div class="col-12 form-box-label">
                                                        <label class="fieldlabels">Passing Year: <span class="requered-field">*</span></label>
                                                    </div>
                                                    <div class="form-box-input">
                                                        <input>
                                                    </div>
                                                    <span class="error">Please Fill</span>
                                                </div>
                                                <div class="col-4 form-box float-left">
                                                    <div class="col-12 form-box-label">
                                                        <label class="fieldlabels">Passing Year: <span class="requered-field">*</span></label>
                                                    </div>
                                                    <div class="form-box-input">
                                                        <input class="input-file" id="my-file" type="file" style="display: none;">
                                                        <label tabindex="0" for="my-file" class="input-file-trigger">Select a file...</label>
                                                    </div>
                                                    <span class="error">Please Fill</span>
                                                </div>
                                                <div class="col-12 text-right">
                                                    <button class="removebtn" style="display: none;"></button>
                                                    <button class="addbtn">ADD</button>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-4 form-box float-left">
                                                    <div class="col-12 form-box-label">
                                                        <label class="fieldlabels">Degree: <span class="requered-field">*</span></label>
                                                    </div>
                                                    <div class="form-box-input">
                                                        <select>
                                                            <option>Select An Option</option>
                                                            <option>Degree</option>
                                                            <option>Degree</option>
                                                        </select>
                                                    </div>
                                                    <span class="error">Please Fill</span>
                                                </div>
                                                <div class="col-4 form-box float-left">
                                                    <div class="col-12 form-box-label">
                                                        <label class="fieldlabels">Passing Year: <span class="requered-field">*</span></label>
                                                    </div>
                                                    <div class="form-box-input">
                                                        <input>
                                                    </div>
                                                    <span class="error">Please Fill</span>
                                                </div>
                                                <div class="col-4 form-box float-left">
                                                    <div class="col-12 form-box-label">
                                                        <label class="fieldlabels">Passing Year: <span class="requered-field">*</span></label>
                                                    </div>
                                                    <div class="form-box-input">
                                                        <input class="input-file" id="my-file" type="file" style="display: none;">
                                                        <label tabindex="0" for="my-file" class="input-file-trigger">Select a file...</label>
                                                    </div>
                                                    <span class="error">Please Fill</span>
                                                </div>
                                                <div class="col-12 text-right">
                                                    <button class="removebtn">REMOVE</button>
                                                    <button class="addbtn">ADD</button>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-12 prf-more-sec">
                                            <div class="col-12">
                                                <h3 class="fs-title">Achivments</h3>
                                            </div>
                                            <div class="row">
                                                <div class="col-4 form-box float-left">
                                                    <div class="col-12 form-box-label">
                                                        <label class="fieldlabels">Degree: <span class="requered-field">*</span></label>
                                                    </div>
                                                    <div class="form-box-input">
                                                        <select>
                                                            <option>Select An Option</option>
                                                            <option>Degree</option>
                                                            <option>Degree</option>
                                                        </select>
                                                    </div>
                                                    <span class="error">Please Fill</span>
                                                </div>
                                                <div class="col-4 form-box float-left">
                                                    <div class="col-12 form-box-label">
                                                        <label class="fieldlabels">Passing Year: <span class="requered-field">*</span></label>
                                                    </div>
                                                    <div class="form-box-input">
                                                        <input>
                                                    </div>
                                                    <span class="error">Please Fill</span>
                                                </div>
                                                <div class="col-4 form-box float-left">
                                                    <div class="col-12 form-box-label">
                                                        <label class="fieldlabels">Passing Year: <span class="requered-field">*</span></label>
                                                    </div>
                                                    <div class="form-box-input">
                                                        <input class="input-file" id="my-file" type="file" style="display: none;">
                                                        <label tabindex="0" for="my-file" class="input-file-trigger">Select a file...</label>
                                                    </div>
                                                    <span class="error">Please Fill</span>
                                                </div>
                                                <div class="col-12 text-right">
                                                    <button class="removebtn" style="display: none;"></button>
                                                    <button class="addbtn">ADD</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <input type="button" name="next" class="next action-button" value="Next" />
                                <input type="button" name="previous" class="previous action-button-previous" value="Previous" />
                            </fieldset>
                            <fieldset>
                                <div class="form-card">
                                    <div class="row">
                                        <div class="col-12 prf-more-sec">
                                            <div class="row">
                                                <div class="col-6 form-box float-left">
                                                    <div class="col-12 form-box-label">
                                                        <label class="fieldlabels">Chamber Name: <span class="requered-field">*</span></label>
                                                    </div>
                                                    <div class="form-box-input">
                                                        <input>
                                                    </div>
                                                    <span class="error">Please Fill</span>
                                                </div>
                                                <div class="col-6 form-box float-left">
                                                    <div class="col-12 form-box-label">
                                                        <label class="fieldlabels">Chamber Owner Name: <span class="requered-field">*</span></label>
                                                    </div>
                                                    <div class="form-box-input">
                                                        <input>
                                                    </div>
                                                    <span class="error">Please Fill</span>
                                                </div>
                                                <div class="col-3 form-box float-left">
                                                    <div class="col-12 form-box-label">
                                                        <label class="fieldlabels">Location: <span class="requered-field">*</span></label>
                                                    </div>
                                                    <div class="form-box-input">
                                                        <input>
                                                    </div>
                                                    <span class="error">Please Fill</span>
                                                </div>
                                                <div class="col-3 form-box float-left">
                                                    <div class="col-12 form-box-label">
                                                        <label class="fieldlabels">City: <span class="requered-field">*</span></label>
                                                    </div>
                                                    <div class="form-box-input">
                                                        <input>
                                                    </div>
                                                    <span class="error">Please Fill</span>
                                                </div>
                                                <div class="col-3 form-box float-left">
                                                    <div class="col-12 form-box-label">
                                                        <label class="fieldlabels">State: <span class="requered-field">*</span></label>
                                                    </div>
                                                    <div class="form-box-input">
                                                        <input>
                                                    </div>
                                                    <span class="error">Please Fill</span>
                                                </div>
                                                <div class="col-3 form-box float-left">
                                                    <div class="col-12 form-box-label">
                                                        <label class="fieldlabels">Zip Code: <span class="requered-field">*</span></label>
                                                    </div>
                                                    <div class="form-box-input">
                                                        <input>
                                                    </div>
                                                    <span class="error">Please Fill</span>
                                                </div>
                                                <div class="col-6 form-box float-left">
                                                    <div class="col-12 form-box-label">
                                                        <label class="fieldlabels">Contact Number: <span class="requered-field">*</span></label>
                                                    </div>
                                                    <div class="col-12 form-box-input">
                                                        <p class="number-code">+91</p>
                                                        <input>
                                                    </div>
                                                    <span class="error">Please Fill</span>
                                                </div>
                                                <div class="col-6 form-box float-left">
                                                    <div class="col-12 form-box-label">
                                                        <label class="fieldlabels">Visit Amount: <span class="requered-field">*</span></label>
                                                    </div>
                                                    <div class="col-12 form-box-input">
                                                        <p class="number-code"><i class="fas fa-rupee-sign"></i></p>
                                                        <input>
                                                    </div>
                                                    <span class="error">Please Fill</span>
                                                </div>
                                                <div class="col-12 text-right">
                                                    <button class="removebtn" style="display: none;"></button>
                                                    <button class="addbtn">ADD</button>
                                                </div>
                                            </div>

                                        </div>

                                    </div>
                                </div>
                                <input type="button" name="next" class="next action-button" value="Next" />
                                <input type="button" name="previous" class="previous action-button-previous" value="Previous" />
                            </fieldset>
                            <fieldset>
                                <div class="form-card">
                                    <div class="row">
                                        <div class="col-7">
                                            <h2 class="fs-title">Image Upload:</h2>
                                        </div>
                                        <div class="col-5">
                                            <h2 class="steps">Step 3 - 4</h2>
                                        </div>
                                    </div> <label class="fieldlabels">Upload Your Photo:</label> <input type="file" name="pic" accept="image/*"> <label class="fieldlabels">Upload Signature Photo:</label> <input type="file" name="pic" accept="image/*">
                                </div> <input type="button" name="next" class="next action-button" value="Submit" /> <input type="button" name="previous" class="previous action-button-previous" value="Previous" />
                            </fieldset>
                            <fieldset>
                                <div class="form-card">
                                    <div class="row">
                                        <div class="col-7">
                                            <h2 class="fs-title">Finish:</h2>
                                        </div>
                                        <div class="col-5">
                                            <h2 class="steps">Step 4 - 4</h2>
                                        </div>
                                    </div> <br><br>
                                    <h2 class="purple-text text-center"><strong>SUCCESS !</strong></h2> <br>
                                    <div class="row justify-content-center">
                                        <div class="col-3"> <img src="https://i.imgur.com/GwStPmg.png" class="fit-image"> </div>
                                    </div> <br><br>
                                    <div class="row justify-content-center">
                                        <div class="col-7 text-center">
                                            <h5 class="purple-text text-center">You Have Successfully Signed Up</h5>
                                        </div>
                                    </div>
                                </div>
                            </fieldset>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

</body>
<script>
    $(document).ready(function() {

        var current_fs, next_fs, previous_fs; //fieldsets
        var opacity;
        var current = 1;
        var steps = $("fieldset").length;

        setProgressBar(current);

        $(".next").click(function() {

            current_fs = $(this).parent();
            next_fs = $(this).parent().next();

            //Add Class Active
            $("#progressbar li").eq($("fieldset").index(next_fs)).addClass("active");

            //show the next fieldset
            next_fs.show();
            //hide the current fieldset with style
            current_fs.animate({
                opacity: 0
            }, {
                step: function(now) {
                    // for making fielset appear animation
                    opacity = 1 - now;

                    current_fs.css({
                        'display': 'none',
                        'position': 'relative'
                    });
                    next_fs.css({
                        'opacity': opacity
                    });
                },
                duration: 500
            });
            setProgressBar(++current);
        });

        $(".previous").click(function() {

            current_fs = $(this).parent();
            previous_fs = $(this).parent().prev();

            //Remove class active
            $("#progressbar li").eq($("fieldset").index(current_fs)).removeClass("active");

            //show the previous fieldset
            previous_fs.show();

            //hide the current fieldset with style
            current_fs.animate({
                opacity: 0
            }, {
                step: function(now) {
                    // for making fielset appear animation
                    opacity = 1 - now;

                    current_fs.css({
                        'display': 'none',
                        'position': 'relative'
                    });
                    previous_fs.css({
                        'opacity': opacity
                    });
                },
                duration: 500
            });
            setProgressBar(--current);
        });

        function setProgressBar(curStep) {
            var percent = parseFloat(100 / steps) * curStep;
            percent = percent.toFixed();
            $(".progress-bar")
                .css("width", percent + "%")
        }

        $(".submit").click(function() {
            return false;
        })

    });
</script>

</html>